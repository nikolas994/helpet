"use client";

import React, { useEffect, useState } from "react";
import { useRouter, useParams } from "next/navigation";
import { message, DatePicker, Select } from "antd";
import dayjs, { Dayjs } from "dayjs";
import pb from "@/app/lib/pocketbase";
import type { Location } from "@/types/location";
import styles from "./BookingPage.module.css";

interface Service {
  id: string;
  name: string;
  description?: string;
  duration: number | string;
  price: number | string;
}

export default function BookingPage() {
  const router = useRouter();
  const params = useParams();
  const locationId = params?.id as string;

  const [messageApi, contextHolder] = message.useMessage();

  const [location, setLocation] = useState<Location | null>(null);
  const [services, setServices] = useState<Service[]>([]);
  const [userPets, setUserPets] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  const [currentStep, setCurrentStep] = useState<number>(1);
  const [selectedServiceId, setSelectedServiceId] = useState<string>("");
  const [selectedPetId, setSelectedPetId] = useState<string>("");
  const [selectedDate, setSelectedDate] = useState<Dayjs | null>(null);
  const [selectedTime, setSelectedTime] = useState<string>("");
  const [note, setNote] = useState<string>("");

  const timeSlots = [
    "09:00",
    "10:00",
    "11:30",
    "13:00",
    "14:30",
    "16:00",
    "17:30",
  ];

  useEffect(() => {
    if (!locationId) return;

    let isMounted = true;

    const fetchData = async () => {
      try {
        setLoading(true);

        // Dodat requestKey: null radi sprečavanja auto-cancel-a
        const locData = await pb
          .collection("locations")
          .getOne<Location>(locationId, {
            requestKey: null,
          });

        const srvData = await pb.collection("services").getFullList<Service>({
          filter: `location = "${locationId}"`,
          sort: "name",
          requestKey: null,
        });

        let petsData: any[] = [];
        if (pb.authStore.model?.id) {
          petsData = await pb.collection("pets").getFullList({
            filter: `owner = "${pb.authStore.model.id}"`,
            requestKey: null,
          });
        }

        if (isMounted) {
          setLocation(locData);
          setServices(srvData);
          setUserPets(petsData);

          if (srvData.length > 0) setSelectedServiceId(srvData[0].id);
          if (petsData.length > 0) setSelectedPetId(petsData[0].id);
        }
      } catch (err: any) {
        // Ignoriši automatski otkazane zahteve
        if (err?.isAbort || err?.name === "AbortError" || err?.status === 0) {
          return;
        }
        console.error("Greška pri učitavanju podataka:", err);
        if (isMounted) {
          messageApi.error("Greška pri učitavanju podataka zakazivanja.");
        }
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    fetchData();

    return () => {
      isMounted = false;
    };
  }, [locationId, messageApi]);

  const selectedService = services.find((s) => s.id === selectedServiceId);
  const selectedPet = userPets.find((p) => p.id === selectedPetId);

  const handleNext = async () => {
    if (currentStep === 1) {
      if (!selectedServiceId) {
        messageApi.warning("Molimo izaberite uslugu.");
        return;
      }
      setCurrentStep(2);
    } else if (currentStep === 2) {
      if (!selectedDate || !selectedTime) {
        messageApi.warning("Molimo izaberite datum i vreme.");
        return;
      }
      if (!selectedPetId) {
        messageApi.warning("Molimo izaberite ljubimca.");
        return;
      }
      setCurrentStep(3);
    } else if (currentStep === 3) {
      if (!selectedDate) {
        messageApi.warning("Molimo izaberite datum.");
        return;
      }

      setSubmitting(true);
      try {
        const [hours, minutes] = selectedTime.split(":").map(Number);
        const appointmentDate = selectedDate
          .hour(hours)
          .minute(minutes)
          .second(0)
          .toISOString();

        const payload = {
          user: pb.authStore.model?.id,
          location: locationId,
          pet: selectedPetId,
          service: selectedServiceId,
          date: appointmentDate,
          note: note,
          status: "pending",
        };

        await pb.collection("appointments").create(payload);
        messageApi.success("Uspešno ste poslali zahtev za zakazivanje!");

        setTimeout(() => {
          router.push("/dashboard/map");
        }, 1500);
      } catch (err: any) {
        console.error(err);
        messageApi.error("Greška pri zakazivanju. Pokušajte ponovo.");
      } finally {
        setSubmitting(false);
      }
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep((prev) => prev - 1);
    } else {
      router.back();
    }
  };

  if (loading) {
    return (
      <div
        className={styles.container}
        style={{ textAlign: "center", paddingTop: 100 }}
      >
        <p>Učitavanje podataka o rezervaciji...</p>
      </div>
    );
  }

  return (
    <div className={styles.container}>
      {contextHolder}

      {/* Header & Stepper */}
      <div className={styles.headerRow}>
        <button className={styles.backButton} onClick={handleBack}>
          ← Nazad
        </button>

        <div className={styles.stepper}>
          <div
            className={`${styles.step} ${
              currentStep >= 1 ? styles.activeStep : ""
            }`}
          >
            01
          </div>
          <div className={styles.stepLine} />
          <div
            className={`${styles.step} ${
              currentStep >= 2 ? styles.activeStep : ""
            }`}
          >
            02
          </div>
          <div className={styles.stepLine} />
          <div
            className={`${styles.step} ${
              currentStep >= 3 ? styles.activeStep : ""
            }`}
          >
            03
          </div>
        </div>
      </div>

      {/* Profile Card Info */}
      <div className={styles.profileCard}>
        <div className={styles.profileAvatar}>
          {location?.type === "vet" ? "🩺" : "✨"}
        </div>
        <div className={styles.profileDetails}>
          <span className={styles.badge}>
            {location?.type?.toUpperCase() || "LOKACIJA"}
          </span>
          <h2>{location?.name || "Naziv objekta"}</h2>
          <div className={styles.metaRow}>
            {location?.address && <span>📍 {location.address}</span>}
            {location?.phone && <span>📞 {location.phone}</span>}
          </div>
        </div>
      </div>

      {/* Content Card */}
      <div className={styles.contentCard}>
        {currentStep === 1 && (
          <div>
            <div className={styles.stepTitle}>
              <span className={styles.stepNumber}>01</span>
              <div>
                <h3>Izaberi uslugu</h3>
                <p>Odaberi uslugu koju želiš da zakažeš.</p>
              </div>
            </div>

            <div className={styles.servicesList}>
              {services.map((service) => {
                const isSelected = selectedServiceId === service.id;
                return (
                  <div
                    key={service.id}
                    className={`${styles.serviceItem} ${
                      isSelected ? styles.selectedService : ""
                    }`}
                    onClick={() => setSelectedServiceId(service.id)}
                  >
                    <div className={styles.serviceIcon}>➕</div>
                    <div className={styles.serviceInfo}>
                      <h4>{service.name}</h4>
                      {service.description && <p>{service.description}</p>}
                      <small>⏱ {service.duration} min</small>
                    </div>
                    <div className={styles.servicePrice}>
                      <strong>{service.price} RSD</strong>
                      {isSelected && (
                        <span className={styles.checkBadge}>✓</span>
                      )}
                    </div>
                  </div>
                );
              })}
              {services.length === 0 && (
                <p style={{ color: "#888" }}>
                  Trenutno nema dostupnih usluga za ovu lokaciju.
                </p>
              )}
            </div>
          </div>
        )}

        {currentStep === 2 && (
          <div>
            <div className={styles.stepTitle}>
              <span className={styles.stepNumber}>02</span>
              <div>
                <h3>Izaberi datum, vreme i ljubimca</h3>
                <p>Odaberi odgovarajući termin i izaberi za koga zakazuješ.</p>
              </div>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
              <div>
                <label
                  style={{ display: "block", marginBottom: 8, fontWeight: 600 }}
                >
                  Izaberi ljubimca:
                </label>
                <Select
                  size="large"
                  style={{ width: "100%", borderRadius: 10 }}
                  value={selectedPetId}
                  onChange={(val) => setSelectedPetId(val)}
                  placeholder="Izaberi ljubimca"
                >
                  {userPets.map((pet) => (
                    <Select.Option key={pet.id} value={pet.id}>
                      🐾 {pet.name} {pet.type ? `(${pet.type})` : ""}
                    </Select.Option>
                  ))}
                </Select>
              </div>

              <div>
                <label
                  style={{ display: "block", marginBottom: 8, fontWeight: 600 }}
                >
                  Izaberi datum:
                </label>
                <DatePicker
                  size="large"
                  style={{ width: "100%", borderRadius: 10 }}
                  disabledDate={(current) =>
                    current && current < dayjs().startOf("day")
                  }
                  value={selectedDate}
                  onChange={(date) => setSelectedDate(date)}
                />
              </div>

              {selectedDate && (
                <div>
                  <label
                    style={{
                      display: "block",
                      marginBottom: 8,
                      fontWeight: 600,
                    }}
                  >
                    Slobodni termini:
                  </label>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
                    {timeSlots.map((time) => {
                      const isSelected = selectedTime === time;
                      return (
                        <button
                          key={time}
                          type="button"
                          onClick={() => setSelectedTime(time)}
                          style={{
                            padding: "8px 16px",
                            borderRadius: 8,
                            border: isSelected
                              ? "2px solid #ea580c"
                              : "1px solid #d1d5db",
                            background: isSelected ? "#fff7ed" : "#fff",
                            color: isSelected ? "#ea580c" : "#374151",
                            fontWeight: isSelected ? 700 : 500,
                            cursor: "pointer",
                          }}
                        >
                          {time}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {currentStep === 3 && (
          <div>
            <div className={styles.stepTitle}>
              <span className={styles.stepNumber}>03</span>
              <div>
                <h3>Potvrda rezervacije</h3>
                <p>
                  Proveri podatke pre nego što definitivno potvrdiš zakazivanje.
                </p>
              </div>
            </div>

            <div
              style={{
                background: "#f9fafb",
                padding: 20,
                borderRadius: 12,
                display: "flex",
                flexDirection: "column",
                gap: 12,
              }}
            >
              <div>
                <strong>Objekat:</strong> {location?.name}
              </div>
              <div>
                <strong>Usluga:</strong> {selectedService?.name} (
                {selectedService?.price} RSD)
              </div>
              <div>
                <strong>Ljubimac:</strong> {selectedPet?.name || "Nije izabran"}
              </div>
              <div>
                <strong>Datum i vreme:</strong>{" "}
                {selectedDate?.format("DD.MM.YYYY.")} u {selectedTime} h
              </div>
            </div>

            <div style={{ marginTop: 20 }}>
              <label
                style={{ display: "block", marginBottom: 8, fontWeight: 600 }}
              >
                Napomena (opciono):
              </label>
              <textarea
                rows={3}
                style={{
                  width: "100%",
                  padding: 12,
                  borderRadius: 10,
                  border: "1px solid #d1d5db",
                }}
                placeholder="Napišite napomenu za osoblje..."
                value={note}
                onChange={(e) => setNote(e.target.value)}
              />
            </div>
          </div>
        )}

        <div className={styles.footerRow}>
          <button
            className={styles.nextButton}
            onClick={handleNext}
            disabled={submitting}
          >
            {submitting
              ? "Slanje..."
              : currentStep === 3
              ? "Potvrdi i Zakaži"
              : "Nastavi →"}
          </button>
        </div>
      </div>
    </div>
  );
}
