"use client";

import React, { useEffect, useState } from "react";
import {
  Table,
  Tag,
  Button,
  Card,
  Popconfirm,
  message,
  Typography,
} from "antd";
import {
  CalendarOutlined,
  EnvironmentOutlined,
  DeleteOutlined,
} from "@ant-design/icons";
import dayjs from "dayjs";
import pb from "@/app/lib/pocketbase";
import styles from "./my-appointments.module.css";

const { Title, Text } = Typography;

export default function MyAppointmentsPage() {
  const [messageApi, contextHolder] = message.useMessage();
  const [loading, setLoading] = useState(true);
  const [appointments, setAppointments] = useState<any[]>([]);

  useEffect(() => {
    fetchAppointments();
  }, []);

  const fetchAppointments = async () => {
    try {
      setLoading(true);
      const userId = pb.authStore.model?.id;
      if (!userId) return;

      const data = await pb.collection("appointments").getFullList({
        filter: `user = "${userId}"`,
        expand: "location,pet,service",
        sort: "-date",
        requestKey: null,
      });

      setAppointments(data);
    } catch (err) {
      console.error("Greška pri preuzimanju termina:", err);
      messageApi.error("Greška pri preuzimanju vaših termina.");
    } finally {
      setLoading(false);
    }
  };

  const handleCancelAppointment = async (id: string) => {
    try {
      await pb.collection("appointments").delete(id);
      messageApi.success("Termin je uspešno otkazan.");
      fetchAppointments();
    } catch (err) {
      messageApi.error("Greška pri otkazivanju termina.");
    }
  };

  const columns = [
    {
      title: "Objekat",
      dataIndex: ["expand", "location", "name"],
      key: "location",
      render: (text: string, record: any) => (
        <div>
          <div className={styles.locationName}>{text || "N/A"}</div>
          <div className={styles.locationAddress}>
            <EnvironmentOutlined />{" "}
            {record.expand?.location?.address || "Nepoznata adresa"}
          </div>
        </div>
      ),
    },
    {
      title: "Ljubimac",
      dataIndex: ["expand", "pet", "name"],
      key: "pet",
      render: (text: string) => (
        <span style={{ fontWeight: 500 }}>🐾 {text || "N/A"}</span>
      ),
    },
    {
      title: "Usluga",
      dataIndex: ["expand", "service", "name"],
      key: "service",
      render: (text: string, record: any) => (
        <div>
          <div style={{ fontWeight: 500, color: "#1e293b" }}>
            {text || "N/A"}
          </div>
          {record.expand?.service?.price && (
            <div className={styles.servicePrice}>
              {record.expand.service.price} RSD
            </div>
          )}
        </div>
      ),
    },
    {
      title: "Datum i Vreme",
      dataIndex: "date",
      key: "date",
      render: (date: string) => (
        <div className={styles.dateBadge}>
          <CalendarOutlined style={{ color: "#6366f1" }} />
          {dayjs(date).format("DD.MM.YYYY. u HH:mm")}
        </div>
      ),
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (status: string) => {
        let color = "orange";
        let label = "ČEKA POTVRDU";

        if (status === "confirmed") {
          color = "green";
          label = "POTVRĐENO";
        } else if (status === "rejected") {
          color = "red";
          label = "ODBIJENO";
        }

        return (
          <Tag color={color} style={{ borderRadius: 6, fontWeight: 600 }}>
            {label}
          </Tag>
        );
      },
    },
    {
      title: "Akcija",
      key: "action",
      render: (_: any, record: any) => (
        <Popconfirm
          title="Otkazivanje termina"
          description="Da li ste sigurni da želite da otkažete ovaj termin?"
          onConfirm={() => handleCancelAppointment(record.id)}
          okText="Da, otkaži"
          cancelText="Ne"
        >
          <Button
            danger
            type="text"
            icon={<DeleteOutlined />}
            size="small"
            className={styles.cancelBtn}
          >
            Otkaži
          </Button>
        </Popconfirm>
      ),
    },
  ];

  return (
    <div className={styles.container}>
      {contextHolder}

      <div className={styles.titleWrapper}>
        <div>
          <Title level={2} style={{ marginBottom: 4 }}>
            Moji Termini
          </Title>
          <Text type="secondary">
            Pregled svih zakazanih poseta i njihovih statusa
          </Text>
        </div>
      </div>

      <Card className={styles.headerCard} style={{ marginTop: 20 }}>
        <Table
          columns={columns}
          dataSource={appointments}
          rowKey="id"
          loading={loading}
          pagination={{ pageSize: 8 }}
        />
      </Card>
    </div>
  );
}
