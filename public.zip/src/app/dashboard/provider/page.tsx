"use client";

import React, { useEffect, useState } from "react";
import {
  Tabs,
  Table,
  Tag,
  Button,
  Modal,
  Form,
  Input,
  InputNumber,
  message,
  Card,
} from "antd";
import {
  CheckOutlined,
  CloseOutlined,
  PlusOutlined,
  DeleteOutlined,
} from "@ant-design/icons";
import dayjs from "dayjs";
import pb from "@/app/lib/pocketbase";

export default function ProviderDashboard() {
  const [messageApi, contextHolder] = message.useMessage();
  const [loading, setLoading] = useState(true);

  const [location, setLocation] = useState<any>(null);
  const [services, setServices] = useState<any[]>([]);
  const [appointments, setAppointments] = useState<any[]>([]);

  // Modal stanja za novu uslugu
  const [isServiceModalOpen, setIsServiceModalOpen] = useState(false);
  const [serviceForm] = Form.useForm();
  const [submittingService, setSubmittingService] = useState(false);

  useEffect(() => {
    fetchProviderData();
  }, []);

  const fetchProviderData = async () => {
    try {
      setLoading(true);
      const userId = pb.authStore.model?.id;
      if (!userId) return;

      // 1. Učitaj lokaciju vezanu za ulogovanog korisnika
      const locList = await pb.collection("locations").getList(1, 1, {
        filter: `owner = "${userId}"`,
        requestKey: null,
      });

      if (locList.items.length > 0) {
        const currentLoc = locList.items[0];
        setLocation(currentLoc);

        // 2. Učitaj usluge za tu lokaciju
        const srvData = await pb.collection("services").getFullList({
          filter: `location = "${currentLoc.id}"`,
          sort: "name",
          requestKey: null,
        });
        setServices(srvData);

        // 3. Učitaj sve rezervacije za tu lokaciju
        const appData = await pb.collection("appointments").getFullList({
          filter: `location = "${currentLoc.id}"`,
          expand: "user,pet,service",
          sort: "-date",
          requestKey: null,
        });
        setAppointments(appData);
      }
    } catch (err) {
      console.error("Greška pri učitavanju provider podataka:", err);
      messageApi.error("Greška pri učitavanju podataka.");
    } finally {
      setLoading(false);
    }
  };

  // Dodavanje nove usluge
  const handleAddService = async (values: any) => {
    if (!location) return;
    setSubmittingService(true);
    try {
      await pb.collection("services").create({
        location: location.id,
        name: values.name,
        description: values.description || "",
        duration: values.duration,
        price: values.price,
      });

      messageApi.success("Usluga uspešno dodata!");
      setIsServiceModalOpen(false);
      serviceForm.resetFields();
      fetchProviderData();
    } catch (err) {
      console.error(err);
      messageApi.error("Greška pri kreiranju usluge.");
    } finally {
      setSubmittingService(false);
    }
  };

  // Brisanje usluge
  const handleDeleteService = async (id: string) => {
    try {
      await pb.collection("services").delete(id);
      messageApi.success("Usluga obrisana.");
      fetchProviderData();
    } catch (err) {
      messageApi.error("Greška pri brisanju usluge.");
    }
  };

  // Promena statusa rezervacije (Potvrdi / Odbij)
  const handleUpdateAppointmentStatus = async (
    id: string,
    newStatus: string,
  ) => {
    try {
      await pb.collection("appointments").update(id, { status: newStatus });
      messageApi.success(
        `Rezervacija je ${
          newStatus === "confirmed" ? "potvrđena" : "odbijena"
        }.`,
      );
      fetchProviderData();
    } catch (err) {
      messageApi.error("Greška pri ažuriranju statusa.");
    }
  };

  if (loading) {
    return (
      <div style={{ padding: 40, textAlign: "center" }}>
        Učitavanje kontrolne table...
      </div>
    );
  }

  if (!location) {
    return (
      <div style={{ padding: 40, textAlign: "center" }}>
        <h2>Nemate registrovan objekat.</h2>
        <p>
          Kontaktirajte administratora da poveže vaš nalog sa objektom u bazi.
        </p>
      </div>
    );
  }

  // Kolone za tabelu rezervacija
  const appointmentColumns = [
    {
      title: "Klijent",
      dataIndex: ["expand", "user", "name"],
      key: "user",
      render: (text: string, record: any) =>
        text || record.expand?.user?.email || "N/A",
    },
    {
      title: "Ljubimac",
      dataIndex: ["expand", "pet", "name"],
      key: "pet",
      render: (text: string) => <span>🐾 {text || "N/A"}</span>,
    },
    {
      title: "Usluga",
      dataIndex: ["expand", "service", "name"],
      key: "service",
    },
    {
      title: "Datum i Vreme",
      dataIndex: "date",
      key: "date",
      render: (date: string) => dayjs(date).format("DD.MM.YYYY. HH:mm"),
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (status: string) => {
        let color = "orange";
        if (status === "confirmed") color = "green";
        if (status === "rejected") color = "red";
        return <Tag color={color}>{status.toUpperCase()}</Tag>;
      },
    },
    {
      title: "Akcije",
      key: "actions",
      render: (_: any, record: any) => (
        <div style={{ display: "flex", gap: 8 }}>
          {record.status === "pending" && (
            <>
              <Button
                type="primary"
                icon={<CheckOutlined />}
                size="small"
                onClick={() =>
                  handleUpdateAppointmentStatus(record.id, "confirmed")
                }
              >
                Potvrdi
              </Button>
              <Button
                danger
                icon={<CloseOutlined />}
                size="small"
                onClick={() =>
                  handleUpdateAppointmentStatus(record.id, "rejected")
                }
              >
                Odbij
              </Button>
            </>
          )}
        </div>
      ),
    },
  ];

  return (
    <div style={{ padding: 24, maxWidth: 1200, margin: "0 auto" }}>
      {contextHolder}

      <Card
        style={{
          marginBottom: 24,
          background: "linear-gradient(135deg, #1e293b, #0f172a)",
          color: "#fff",
        }}
      >
        <h1 style={{ color: "#fff", margin: 0 }}>{location.name}</h1>
        <p style={{ color: "#94a3b8", margin: "4px 0 0 0" }}>
          📍 {location.address} | 📞 {location.phone || "Nema telefona"}
        </p>
      </Card>

      <Tabs
        defaultActiveKey="1"
        items={[
          {
            key: "1",
            label: "Zakazani Termini",
            children: (
              <Table
                columns={appointmentColumns}
                dataSource={appointments}
                rowKey="id"
                pagination={{ pageSize: 10 }}
              />
            ),
          },
          {
            key: "2",
            label: "Cenovnik i Usluge",
            children: (
              <div>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    marginBottom: 16,
                  }}
                >
                  <h3>Upravljanje uslugama</h3>
                  <Button
                    type="primary"
                    icon={<PlusOutlined />}
                    onClick={() => setIsServiceModalOpen(true)}
                  >
                    Dodaj novu uslugu
                  </Button>
                </div>

                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns:
                      "repeat(auto-fill, minmax(280px, 1fr))",
                    gap: 16,
                  }}
                >
                  {services.map((srv) => (
                    <Card
                      key={srv.id}
                      size="small"
                      actions={[
                        <DeleteOutlined
                          key="delete"
                          style={{ color: "red" }}
                          onClick={() => handleDeleteService(srv.id)}
                        />,
                      ]}
                    >
                      <h4>{srv.name}</h4>
                      <p style={{ color: "#666", fontSize: 13 }}>
                        {srv.description || "Nema opisa"}
                      </p>
                      <div
                        style={{
                          display: "flex",
                          justifyContent: "space-between",
                          fontWeight: "bold",
                          marginTop: 12,
                        }}
                      >
                        <span>⏱ {srv.duration} min</span>
                        <span style={{ color: "#10b981" }}>
                          {srv.price} RSD
                        </span>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            ),
          },
        ]}
      />

      {/* MODAL ZA DODAVANJE USLUGE */}
      <Modal
        title="Dodaj novu uslugu"
        open={isServiceModalOpen}
        onCancel={() => setIsServiceModalOpen(false)}
        footer={null}
      >
        <Form form={serviceForm} layout="vertical" onFinish={handleAddService}>
          <Form.Item
            name="name"
            label="Naziv usluge"
            rules={[{ required: true, message: "Unesite naziv" }]}
          >
            <Input placeholder="npr. Opšti pregled" />
          </Form.Item>
          <Form.Item name="description" label="Opis usluge">
            <Input.TextArea placeholder="Kratak opis tretmana..." />
          </Form.Item>
          <Form.Item
            name="duration"
            label="Trajanje (minuti)"
            rules={[{ required: true, message: "Unesite trajanje" }]}
          >
            <InputNumber style={{ width: "100%" }} min={5} placeholder="30" />
          </Form.Item>
          <Form.Item
            name="price"
            label="Cena (RSD)"
            rules={[{ required: true, message: "Unesite cenu" }]}
          >
            <InputNumber style={{ width: "100%" }} min={0} placeholder="2500" />
          </Form.Item>

          <Button
            type="primary"
            htmlType="submit"
            loading={submittingService}
            block
            style={{ marginTop: 12 }}
          >
            Sačuvaj uslugu
          </Button>
        </Form>
      </Modal>
    </div>
  );
}
