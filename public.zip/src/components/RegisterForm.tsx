"use client";

import { useState } from "react";
import { Button, Card, Form, Input, Radio, Typography, message } from "antd";
import { UserOutlined, MailOutlined, LockOutlined } from "@ant-design/icons";
import { useRouter } from "next/navigation";
import pb from "../app/lib/pocketbase";

const { Title, Text } = Typography;

export default function RegisterForm() {
  const [messageApi, contextHolder] = message.useMessage();
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleRedirectByRole = (role?: string) => {
    if (role === "provider") {
      router.push("/dashboard/provider");
    } else {
      router.push("/dashboard/map");
    }
  };

  const onFinish = async (values: any) => {
    setLoading(true);
    try {
      // 1. Kreiranje korisnika sa definisanom ulogom (role)
      await pb.collection("users").create({
        name: values.name,
        email: values.email,
        password: values.password,
        passwordConfirm: values.passwordConfirm,
        role: values.role,
      });

      // 2. Automatski login posle registracije
      const authData = await pb
        .collection("users")
        .authWithPassword(values.email, values.password);

      messageApi.success("Registracija uspešna");

      // 3. Prebacivanje na odgovarajući dashboard na osnovu uloge
      handleRedirectByRole(authData.record?.role);
    } catch (error: any) {
      console.log(
        "ERROR DATA:",
        JSON.stringify(error?.response?.data, null, 2),
      );
      messageApi.error("Greška prilikom registracije");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {contextHolder}

      <Card
        style={{
          width: 400,
          borderRadius: 20,
        }}
      >
        <Title level={2} style={{ textAlign: "center", marginBottom: 4 }}>
          Kreiraj nalog
        </Title>

        <Text
          type="secondary"
          style={{ display: "block", textAlign: "center", marginBottom: 20 }}
        >
          Registrujte se da nastavite
        </Text>

        <Form
          layout="vertical"
          onFinish={onFinish}
          initialValues={{ role: "client" }}
        >
          <Form.Item
            label="Ime"
            name="name"
            rules={[
              {
                required: true,
                message: "Unesite ime",
              },
            ]}
          >
            <Input
              prefix={<UserOutlined />}
              size="large"
              placeholder="Ime i prezime"
            />
          </Form.Item>

          <Form.Item
            label="Tip naloga"
            name="role"
            rules={[{ required: true, message: "Izaberite tip naloga" }]}
          >
            <Radio.Group
              buttonStyle="solid"
              size="large"
              style={{ width: "100%", display: "flex" }}
            >
              <Radio.Button
                value="client"
                style={{ flex: 1, textAlign: "center" }}
              >
                🐾 Klijent
              </Radio.Button>
              <Radio.Button
                value="provider"
                style={{ flex: 1, textAlign: "center" }}
              >
                🩺 Veterinar / Salon
              </Radio.Button>
            </Radio.Group>
          </Form.Item>

          <Form.Item
            label="Email"
            name="email"
            rules={[
              {
                required: true,
                message: "Unesite email",
              },
              {
                type: "email",
                message: "Email nije validan",
              },
            ]}
          >
            <Input prefix={<MailOutlined />} size="large" placeholder="Email" />
          </Form.Item>

          <Form.Item
            label="Lozinka"
            name="password"
            rules={[
              {
                required: true,
                message: "Unesite lozinku",
              },
              {
                validator(_, value) {
                  if (!value) {
                    return Promise.resolve();
                  }

                  const hasMinLength = value.length >= 8;
                  const hasUpperCase = /[A-Z]/.test(value);
                  const hasNumber = /[0-9]/.test(value);
                  const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(value);

                  if (
                    hasMinLength &&
                    hasUpperCase &&
                    hasNumber &&
                    hasSpecialChar
                  ) {
                    return Promise.resolve();
                  }

                  return Promise.reject(
                    new Error(
                      "Lozinka mora imati minimum 8 karaktera, jedno veliko slovo, broj i specijalni karakter",
                    ),
                  );
                },
              },
            ]}
          >
            <Input.Password
              prefix={<LockOutlined />}
              size="large"
              placeholder="Lozinka"
            />
          </Form.Item>

          <Form.Item
            label="Ponovi lozinku"
            name="passwordConfirm"
            dependencies={["password"]}
            rules={[
              {
                required: true,
                message: "Ponovite lozinku",
              },

              ({ getFieldValue }) => ({
                validator(_, value) {
                  if (!value || getFieldValue("password") === value) {
                    return Promise.resolve();
                  }

                  return Promise.reject(new Error("Lozinke se ne poklapaju"));
                },
              }),
            ]}
          >
            <Input.Password
              prefix={<LockOutlined />}
              size="large"
              placeholder="Ponovite lozinku"
            />
          </Form.Item>

          <Button
            type="primary"
            htmlType="submit"
            size="large"
            block
            loading={loading}
          >
            Registruj se
          </Button>

          <div
            style={{
              marginTop: 20,
              textAlign: "center",
            }}
          >
            <Text>
              Već imate nalog? <a href="/login">Prijavite se</a>
            </Text>
          </div>
        </Form>
      </Card>
    </>
  );
}
