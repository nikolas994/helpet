"use client";

import { useEffect, useState } from "react";
import { Button, Card, Form, Input, Typography, message } from "antd";
import { MailOutlined, LockOutlined } from "@ant-design/icons";
import { useRouter } from "next/navigation";
import pb from "../app/lib/pocketbase";

const { Title, Text } = Typography;

export default function LoginForm() {
  const router = useRouter();
  const [messageApi, contextHolder] = message.useMessage();
  const [loading, setLoading] = useState(false);

  // Funkcija za usmeravanje na osnovu uloge korisnika
  const handleRedirectByRole = (role?: string) => {
    if (role === "provider") {
      router.push("/dashboard/provider");
    } else {
      router.push("/dashboard/map");
    }
  };

  // Ako je korisnik već ulogovan, odmah ga preusmeri
  useEffect(() => {
    if (pb.authStore.isValid && pb.authStore.model) {
      handleRedirectByRole(pb.authStore.model.role);
    }
  }, []);

  const onFinish = async (values: any) => {
    setLoading(true);
    try {
      const authData = await pb
        .collection("users")
        .authWithPassword(values.email, values.password);

      messageApi.success("Uspešna prijava");

      // Preusmeravanje zavisi od role polja iz PocketBase-a
      handleRedirectByRole(authData.record?.role);
    } catch (error) {
      messageApi.error("Pogrešan email ili lozinka");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {contextHolder}

      <Card
        style={{
          width: 400,
          borderRadius: 20,
        }}
      >
        <Title level={2} style={{ textAlign: "center", marginBottom: 4 }}>
          Dobrodošli
        </Title>

        <Text
          type="secondary"
          style={{ display: "block", textAlign: "center", marginBottom: 20 }}
        >
          Prijavite se na svoj nalog
        </Text>

        <Form layout="vertical" onFinish={onFinish}>
          <Form.Item
            label="Email"
            name="email"
            rules={[
              {
                required: true,
                message: "Unesite email",
              },
              {
                type: "email",
                message: "Unesite validan email",
              },
            ]}
          >
            <Input prefix={<MailOutlined />} placeholder="Email" size="large" />
          </Form.Item>

          <Form.Item
            label="Lozinka"
            name="password"
            rules={[
              {
                required: true,
                message: "Unesite lozinku",
              },
            ]}
          >
            <Input.Password
              prefix={<LockOutlined />}
              placeholder="Lozinka"
              size="large"
            />
          </Form.Item>

          <Button
            htmlType="submit"
            type="primary"
            block
            size="large"
            loading={loading}
          >
            Prijavi se
          </Button>

          <div
            style={{
              marginTop: 20,
              textAlign: "center",
            }}
          >
            <Text>
              Nemate nalog? <a href="/register">Registrujte se</a>
            </Text>
          </div>
        </Form>
      </Card>
    </>
  );
}
