const POCKETBASE_URL = "http://127.0.0.1:8090";

async function deleteAllLocations() {
  try {
    console.log("🔍 Preuzimam sve lokacije za brisanje...");
    const res = await fetch(
      `${POCKETBASE_URL}/api/collections/locations/records?perPage=500`,
    );
    const data = await res.json();

    if (!data.items || data.items.length === 0) {
      console.log("Kolekcija 'locations' je već prazna.");
      return;
    }

    console.log(
      `🗑️ Pronađeno ${data.items.length} lokacija. Započinjem brisanje...`,
    );

    for (const item of data.items) {
      const delRes = await fetch(
        `${POCKETBASE_URL}/api/collections/locations/records/${item.id}`,
        {
          method: "DELETE",
        },
      );
      if (delRes.ok) {
        console.log(`✅ Obbrisano: ${item.name} (${item.id})`);
      } else {
        console.error(`❌ Greška pri brisanju: ${item.id}`);
      }
    }
    console.log("🎉 Sve lokacije su uspešno obrisane!");
  } catch (err) {
    console.error("Greška:", err);
  }
}

deleteAllLocations();
