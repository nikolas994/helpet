"use client";

import { useState } from "react";

import { Button, Card, Form, Input, Typography, message } from "antd";

import {
  LockOutlined,
  MailOutlined,
  UserOutlined,
  ArrowRightOutlined,
} from "@ant-design/icons";

import Link from "next/link";
import { useRouter } from "next/navigation";

import pb from "@/app/lib/pocketbase";

import styles from "./RegisterForm.module.css";

const { Title, Text } = Typography;

interface RegisterValues {
  name: string;
  email: string;
  password: string;
  passwordConfirm: string;
}

export default function RegisterForm() {
  const router = useRouter();

  const [messageApi, contextHolder] = message.useMessage();

  const [loading, setLoading] = useState(false);

  const onFinish = async (values: RegisterValues) => {
    if (loading) {
      return;
    }

    setLoading(true);

    try {
      /*
       * NOVI KORISNIK JE UVEK CLIENT.
       *
       * Nikada ne uzimamo role sa frontenda.
       */
      await pb.collection("users").create({
        name: values.name.trim(),
        email: values.email.trim().toLowerCase(),
        password: values.password,
        passwordConfirm: values.passwordConfirm,
        role: "client",
      });

      /*
       * Automatski login
       */
      const authData = await pb
        .collection("users")
        .authWithPassword(values.email.trim().toLowerCase(), values.password);

      if (!authData.record) {
        throw new Error("Registracija je uspešna, ali prijava nije uspela.");
      }

      messageApi.success("Nalog je uspešno kreiran.");

      router.replace("/dashboard/map");
    } catch (error: any) {
      console.error("REGISTER ERROR:", error);

      const data = error?.response?.data;

      if (data?.email?.code === "validation_not_unique") {
        messageApi.error("Nalog sa ovim emailom već postoji.");
      } else {
        messageApi.error(
          "Registracija nije uspela. Proverite podatke i pokušajte ponovo.",
        );
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {contextHolder}

      <div className={styles.wrapper}>
        <Card className={styles.card} bordered={false}>
          <div className={styles.brand}>
            <div className={styles.logo}>🐾</div>

            <span>HELPet</span>
          </div>

          <div className={styles.heading}>
            <Title level={1}>Kreiraj nalog</Title>

            <Text>Pridruži se HELPet zajednici.</Text>
          </div>

          <Form<RegisterValues>
            layout="vertical"
            onFinish={onFinish}
            requiredMark={false}
            autoComplete="on"
          >
            <Form.Item
              label="Ime"
              name="name"
              rules={[
                {
                  required: true,
                  message: "Unesite ime.",
                },
                {
                  min: 2,
                  message: "Ime mora imati najmanje 2 karaktera.",
                },
              ]}
            >
              <Input
                prefix={<UserOutlined />}
                size="large"
                placeholder="Ime i prezime"
                autoComplete="name"
                disabled={loading}
              />
            </Form.Item>

            <Form.Item
              label="Email"
              name="email"
              rules={[
                {
                  required: true,
                  message: "Unesite email.",
                },
                {
                  type: "email",
                  message: "Unesite validan email.",
                },
              ]}
            >
              <Input
                prefix={<MailOutlined />}
                size="large"
                placeholder="vas@email.com"
                autoComplete="email"
                disabled={loading}
              />
            </Form.Item>

            <Form.Item
              label="Lozinka"
              name="password"
              rules={[
                {
                  required: true,
                  message: "Unesite lozinku.",
                },
                {
                  validator(_, value) {
                    if (!value) {
                      return Promise.resolve();
                    }

                    const validLength = value.length >= 8;

                    const uppercase = /[A-Z]/.test(value);

                    const number = /[0-9]/.test(value);

                    const special = /[^A-Za-z0-9]/.test(value);

                    if (validLength && uppercase && number && special) {
                      return Promise.resolve();
                    }

                    return Promise.reject(
                      new Error(
                        "Minimum 8 karaktera, jedno veliko slovo, jedan broj i jedan specijalni karakter.",
                      ),
                    );
                  },
                },
              ]}
            >
              <Input.Password
                prefix={<LockOutlined />}
                size="large"
                placeholder="Vaša lozinka"
                autoComplete="new-password"
                disabled={loading}
              />
            </Form.Item>

            <Form.Item
              label="Ponovi lozinku"
              name="passwordConfirm"
              dependencies={["password"]}
              rules={[
                {
                  required: true,
                  message: "Ponovite lozinku.",
                },
                ({ getFieldValue }) => ({
                  validator(_, value) {
                    if (!value || value === getFieldValue("password")) {
                      return Promise.resolve();
                    }

                    return Promise.reject(
                      new Error("Lozinke se ne poklapaju."),
                    );
                  },
                }),
              ]}
            >
              <Input.Password
                prefix={<LockOutlined />}
                size="large"
                placeholder="Ponovite lozinku"
                autoComplete="new-password"
                disabled={loading}
              />
            </Form.Item>

            <Button
              type="primary"
              htmlType="submit"
              size="large"
              block
              loading={loading}
              icon={<ArrowRightOutlined />}
              iconPosition="end"
              className={styles.submitButton}
            >
              Registruj se
            </Button>
          </Form>

          <div className={styles.footer}>
            <Text type="secondary">Već imate nalog?</Text>

            <Link href="/login">Prijavite se</Link>
          </div>
        </Card>
      </div>
    </>
  );
}
