"use client";

import { useEffect, useState } from "react";
import { Button, Card, Form, Input, Typography, message } from "antd";
import {
  LockOutlined,
  MailOutlined,
  ArrowRightOutlined,
} from "@ant-design/icons";
import Link from "next/link";
import { useRouter } from "next/navigation";

import pb from "../app/lib/pocketbase";
import styles from "./LoginForm.module.css";

const { Title, Text } = Typography;

interface LoginValues {
  email: string;
  password: string;
}

export default function LoginForm() {
  const router = useRouter();
  const [messageApi, contextHolder] = message.useMessage();

  const [loading, setLoading] = useState(false);
  const [checkingAuth, setCheckingAuth] = useState(true);

  /*
   * =========================================================
   * REDIRECT PO ULOZI
   * =========================================================
   */

  const redirectByRole = (role?: string) => {
    if (role === "provider") {
      router.replace("/dashboard/provider");
      return;
    }

    router.replace("/dashboard/map");
  };

  /*
   * =========================================================
   * PROVERA POSTOJEĆE SESIJE
   * =========================================================
   */

  useEffect(() => {
    const checkAuth = () => {
      if (pb.authStore.isValid && pb.authStore.model) {
        redirectByRole(pb.authStore.model.role);
        return;
      }

      setCheckingAuth(false);
    };

    checkAuth();
  }, []);

  /*
   * =========================================================
   * LOGIN
   * =========================================================
   */

  const onFinish = async (values: LoginValues) => {
    if (loading) {
      return;
    }

    setLoading(true);

    try {
      const authData = await pb
        .collection("users")
        .authWithPassword(values.email.trim(), values.password);

      const user = authData.record;

      if (!user) {
        throw new Error("Korisnik nije pronađen.");
      }

      messageApi.success("Uspešna prijava.");

      redirectByRole(user.role);
    } catch (error: any) {
      console.error("LOGIN ERROR:", error);

      /*
       * Namerno ne prikazujemo da li email postoji.
       * Ovo sprečava otkrivanje registrovanih email adresa.
       */

      messageApi.error("Email ili lozinka nisu ispravni.");
    } finally {
      setLoading(false);
    }
  };

  /*
   * =========================================================
   * LOADING DOK PROVERAVAMO SESIJU
   * =========================================================
   */

  if (checkingAuth) {
    return (
      <div className={styles.authLoading}>
        <div className={styles.loadingSpinner} />
        <span>Provera sesije...</span>
      </div>
    );
  }

  /*
   * =========================================================
   * LOGIN UI
   * =========================================================
   */

  return (
    <>
      {contextHolder}

      <div className={styles.wrapper}>
        <Card className={styles.card} bordered={false}>
          <div className={styles.brand}>
            <div className={styles.logo}>🐾</div>

            <span>HELPet</span>
          </div>

          <div className={styles.heading}>
            <Title level={1}>Dobrodošli</Title>

            <Text>Prijavite se na svoj HELPet nalog.</Text>
          </div>

          <Form<LoginValues>
            layout="vertical"
            onFinish={onFinish}
            autoComplete="on"
            requiredMark={false}
          >
            <Form.Item
              label="Email"
              name="email"
              rules={[
                {
                  required: true,
                  message: "Unesite email.",
                },
                {
                  type: "email",
                  message: "Unesite validan email.",
                },
              ]}
            >
              <Input
                prefix={<MailOutlined />}
                placeholder="vas@email.com"
                size="large"
                autoComplete="email"
                disabled={loading}
              />
            </Form.Item>

            <Form.Item
              label="Lozinka"
              name="password"
              rules={[
                {
                  required: true,
                  message: "Unesite lozinku.",
                },
              ]}
            >
              <Input.Password
                prefix={<LockOutlined />}
                placeholder="Vaša lozinka"
                size="large"
                autoComplete="current-password"
                disabled={loading}
              />
            </Form.Item>

            <Button
              htmlType="submit"
              type="primary"
              block
              size="large"
              loading={loading}
              icon={<ArrowRightOutlined />}
              iconPosition="end"
              className={styles.submitButton}
            >
              Prijavi se
            </Button>
          </Form>

          <div className={styles.footer}>
            <Text type="secondary">Nemate nalog?</Text>

            <Link href="/register">Registrujte se</Link>
          </div>
        </Card>
      </div>
    </>
  );
}
