"use client";

import { createContext, useContext, useEffect, useMemo, useState } from "react";

import pb from "@/app/lib/pocketbase";

export type UserRole = "client" | "provider";

export interface AuthUser {
  id: string;
  email?: string;
  name?: string;
  username?: string;
  role?: UserRole;
  avatar?: string;
  verified?: boolean;
}

interface AuthContextType {
  user: AuthUser | null;
  loading: boolean;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const syncAuth = () => {
      const model = pb.authStore.model;

      if (pb.authStore.isValid && model) {
        setUser({
          id: model.id,
          email: model.email,
          name: model.name,
          username: model.username,
          role: model.role as UserRole | undefined,
          avatar: model.avatar,
          verified: model.verified,
        });
      } else {
        setUser(null);
      }

      setLoading(false);
    };

    syncAuth();

    const unsubscribe = pb.authStore.onChange(() => {
      syncAuth();
    });

    return () => {
      unsubscribe();
    };
  }, []);

  const logout = () => {
    pb.authStore.clear();
    setUser(null);
  };

  const value = useMemo(
    () => ({
      user,
      loading,
      logout,
    }),
    [user, loading],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);

  if (!context) {
    throw new Error("useAuth mora biti korišćen unutar AuthProvider-a.");
  }

  return context;
}
