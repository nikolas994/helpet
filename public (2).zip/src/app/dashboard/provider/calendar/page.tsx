"use client";

import React, { useEffect, useMemo, useState } from "react";
import { Button, Card, Empty, Modal, Select, Spin, Tag, message } from "antd";

import {
  CalendarOutlined,
  CheckCircleOutlined,
  ClockCircleOutlined,
  CloseCircleOutlined,
  EyeOutlined,
  HeartOutlined,
  MedicineBoxOutlined,
  UserOutlined,
  LeftOutlined,
  RightOutlined,
} from "@ant-design/icons";

import dayjs, { Dayjs } from "dayjs";
import "dayjs/locale/sr";

import { useRouter } from "next/navigation";
import pb from "@/app/lib/pocketbase";
import styles from "./ProviderCalendar.module.css";

dayjs.locale("sr");

/* =========================================================
   TYPES
========================================================= */

interface User {
  id: string;
  name?: string;
  username?: string;
  email?: string;
}

interface Pet {
  id: string;
  name?: string;
  type?: string;
  breed?: string;
  image?: string;
}

interface Service {
  id: string;
  name?: string;
  price?: number;
  duration?: number;
}

interface Appointment {
  id: string;
  user: string;
  location: string;
  pet: string;
  service: string;
  date: string;
  status: "pending" | "confirmed" | "rejected" | "completed";
  note?: string;

  expand?: {
    user?: User;
    pet?: Pet;
    service?: Service;
  };
}

interface Location {
  id: string;
  name: string;
  type?: string;
}

type StatusFilter = "all" | "pending" | "confirmed" | "completed" | "rejected";

/* =========================================================
   PAGE
========================================================= */

export default function ProviderCalendarPage() {
  const router = useRouter();
  const [messageApi, contextHolder] = message.useMessage();

  const [location, setLocation] = useState<Location | null>(null);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);

  const [currentMonth, setCurrentMonth] = useState<Dayjs>(dayjs());
  const [selectedDate, setSelectedDate] = useState<Dayjs>(dayjs());

  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");

  const [selectedAppointment, setSelectedAppointment] =
    useState<Appointment | null>(null);

  const [detailsOpen, setDetailsOpen] = useState(false);
  const [updatingStatus, setUpdatingStatus] = useState(false);

  /* =========================================================
     FETCH DATA
  ========================================================= */

  const fetchData = async () => {
    try {
      setLoading(true);

      const userId = pb.authStore.model?.id;

      if (!userId) {
        router.push("/login");
        return;
      }

      /* -------------------------------------------------------
         PROVIDER LOCATION
      ------------------------------------------------------- */

      const locationResult = await pb
        .collection("locations")
        .getList<Location>(1, 1, {
          filter: `owner = "${userId}"`,
          requestKey: null,
        });

      if (locationResult.items.length === 0) {
        setLocation(null);
        setAppointments([]);
        return;
      }

      const currentLocation = locationResult.items[0];

      setLocation(currentLocation);

      /* -------------------------------------------------------
         APPOINTMENTS
      ------------------------------------------------------- */

      const appointmentResult = await pb
        .collection("appointments")
        .getFullList<Appointment>({
          filter: `location = "${currentLocation.id}"`,
          sort: "date",
          expand: "user,pet,service",
          requestKey: null,
        });

      setAppointments(appointmentResult);
    } catch (error: any) {
      if (
        error?.isAbort ||
        error?.name === "AbortError" ||
        error?.status === 0
      ) {
        return;
      }

      console.error("Greška pri učitavanju kalendara:", error);

      messageApi.error("Greška pri učitavanju termina.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  /* =========================================================
     FILTER
  ========================================================= */

  const filteredAppointments = useMemo(() => {
    if (statusFilter === "all") {
      return appointments;
    }

    return appointments.filter(
      (appointment) => appointment.status === statusFilter,
    );
  }, [appointments, statusFilter]);

  /* =========================================================
     GET APPOINTMENTS FOR DATE
  ========================================================= */

  const getAppointmentsForDate = (date: Dayjs) => {
    return filteredAppointments.filter((appointment) =>
      dayjs(appointment.date).isSame(date, "day"),
    );
  };

  /* =========================================================
     SELECTED DAY
  ========================================================= */

  const selectedDayAppointments = useMemo(() => {
    return getAppointmentsForDate(selectedDate).sort(
      (a, b) => dayjs(a.date).valueOf() - dayjs(b.date).valueOf(),
    );
  }, [filteredAppointments, selectedDate]);

  /* =========================================================
     STATUS TAG
  ========================================================= */

  const getStatusTag = (status: Appointment["status"]) => {
    switch (status) {
      case "pending":
        return (
          <Tag icon={<ClockCircleOutlined />} color="orange">
            ČEKA POTVRDU
          </Tag>
        );

      case "confirmed":
        return (
          <Tag icon={<CheckCircleOutlined />} color="green">
            POTVRĐENO
          </Tag>
        );

      case "completed":
        return (
          <Tag icon={<CheckCircleOutlined />} color="blue">
            ZAVRŠENO
          </Tag>
        );

      case "rejected":
        return (
          <Tag icon={<CloseCircleOutlined />} color="red">
            ODBIJENO
          </Tag>
        );

      default:
        return <Tag>NEPOZNATO</Tag>;
    }
  };

  /* =========================================================
     OPEN DETAILS
  ========================================================= */

  const openDetails = (appointment: Appointment) => {
    setSelectedAppointment(appointment);
    setDetailsOpen(true);
  };

  /* =========================================================
     UPDATE STATUS
  ========================================================= */

  const updateAppointmentStatus = async (status: Appointment["status"]) => {
    if (!selectedAppointment) return;

    try {
      setUpdatingStatus(true);

      const updated = await pb.collection("appointments").update<Appointment>(
        selectedAppointment.id,
        {
          status,
        },
        {
          requestKey: null,
          expand: "user,pet,service",
        },
      );

      /* Update lokalnog appointment-a */
      setAppointments((current) =>
        current.map((appointment) =>
          appointment.id === updated.id ? updated : appointment,
        ),
      );

      setSelectedAppointment(updated);

      messageApi.success(
        status === "confirmed"
          ? "Termin je potvrđen."
          : status === "rejected"
          ? "Termin je odbijen."
          : "Termin je označen kao završen.",
      );
    } catch (error: any) {
      if (
        error?.isAbort ||
        error?.name === "AbortError" ||
        error?.status === 0
      ) {
        return;
      }

      console.error("Greška pri promeni statusa:", error);

      messageApi.error("Nije moguće promeniti status termina.");
    } finally {
      setUpdatingStatus(false);
    }
  };

  /* =========================================================
     MONTH NAVIGATION
  ========================================================= */

  const previousMonth = () => {
    const newMonth = currentMonth.subtract(1, "month");

    setCurrentMonth(newMonth);
    setSelectedDate(newMonth.startOf("month"));
  };

  const nextMonth = () => {
    const newMonth = currentMonth.add(1, "month");

    setCurrentMonth(newMonth);
    setSelectedDate(newMonth.startOf("month"));
  };

  const goToday = () => {
    const today = dayjs();

    setCurrentMonth(today);
    setSelectedDate(today);
  };

  /* =========================================================
     CALENDAR CELLS
  ========================================================= */

  const calendarCells = useMemo(() => {
    const startOfMonth = currentMonth.startOf("month");

    const daysInMonth = currentMonth.daysInMonth();

    const firstDay = (startOfMonth.day() + 6) % 7;

    const cells: React.ReactNode[] = [];

    for (let i = 0; i < firstDay; i++) {
      cells.push(
        <div
          key={`empty-${i}`}
          className={`${styles.dayCell} ${styles.emptyDay}`}
        />,
      );
    }

    for (let day = 1; day <= daysInMonth; day++) {
      const date = currentMonth.date(day);

      const dayAppointments = getAppointmentsForDate(date);

      const isToday = date.isSame(dayjs(), "day");

      const isSelected = date.isSame(selectedDate, "day");

      cells.push(
        <button
          key={day}
          type="button"
          className={`
            ${styles.dayCell}
            ${isToday ? styles.today : ""}
            ${isSelected ? styles.selectedDay : ""}
          `}
          onClick={() => setSelectedDate(date)}
        >
          <span className={styles.dayNumber}>{day}</span>

          {dayAppointments.length > 0 && (
            <div className={styles.dayAppointments}>
              {dayAppointments.slice(0, 3).map((appointment) => (
                <div
                  key={appointment.id}
                  className={`
                      ${styles.miniAppointment}
                      ${styles[appointment.status]}
                    `}
                >
                  <span>{dayjs(appointment.date).format("HH:mm")}</span>

                  <strong>
                    {appointment.expand?.service?.name || "Termin"}
                  </strong>
                </div>
              ))}

              {dayAppointments.length > 3 && (
                <div className={styles.moreAppointments}>
                  +{dayAppointments.length - 3} još
                </div>
              )}
            </div>
          )}
        </button>,
      );
    }

    return cells;
  }, [currentMonth, selectedDate, filteredAppointments]);

  /* =========================================================
     LOADING
  ========================================================= */

  if (loading) {
    return (
      <div className={styles.loading}>
        <Spin size="large" />
        <p>Učitavanje kalendara...</p>
      </div>
    );
  }

  /* =========================================================
     NO LOCATION
  ========================================================= */

  if (!location) {
    return (
      <div className={styles.emptyState}>
        <div className={styles.emptyIcon}>🏢</div>

        <h2>Objekat nije pronađen</h2>

        <p>Vaš nalog nije povezan sa business objektom.</p>

        <Button
          type="primary"
          onClick={() => router.push("/dashboard/provider")}
        >
          Nazad na dashboard
        </Button>
      </div>
    );
  }

  /* =========================================================
     PAGE
  ========================================================= */

  return (
    <div className={styles.page}>
      {contextHolder}

      {/* HEADER */}

      <div className={styles.header}>
        <div>
          <div className={styles.eyebrow}>BUSINESS</div>

          <h1>Kalendar</h1>

          <p>Pregled termina i rasporeda vašeg objekta.</p>
        </div>

        <Button onClick={() => router.push("/dashboard/provider")}>
          ← Nazad
        </Button>
      </div>

      {/* LOCATION */}

      <div className={styles.locationCard}>
        <div className={styles.locationIcon}>
          {location.type === "vet" ? "🩺" : "🐾"}
        </div>

        <div>
          <span>VAŠ OBJEKAT</span>
          <h2>{location.name}</h2>
        </div>
      </div>

      {/* FILTER */}

      <Card className={styles.filterCard}>
        <div className={styles.filterHeader}>
          <div>
            <h2>Pregled termina</h2>

            <p>Filtrirajte termine prema statusu.</p>
          </div>

          <Select
            value={statusFilter}
            onChange={(value) => setStatusFilter(value)}
            className={styles.filter}
            options={[
              {
                value: "all",
                label: "Svi termini",
              },
              {
                value: "pending",
                label: "Čekaju potvrdu",
              },
              {
                value: "confirmed",
                label: "Potvrđeni",
              },
              {
                value: "completed",
                label: "Završeni",
              },
              {
                value: "rejected",
                label: "Odbijeni",
              },
            ]}
          />
        </div>

        <div className={styles.legend}>
          <div>
            <span className={`${styles.legendDot} ${styles.pending}`} />
            Čeka potvrdu
          </div>

          <div>
            <span className={`${styles.legendDot} ${styles.confirmed}`} />
            Potvrđeno
          </div>

          <div>
            <span className={`${styles.legendDot} ${styles.completed}`} />
            Završeno
          </div>

          <div>
            <span className={`${styles.legendDot} ${styles.rejected}`} />
            Odbijeno
          </div>
        </div>
      </Card>

      {/* CALENDAR */}

      <Card className={styles.calendarCard}>
        <div className={styles.calendarWrapper}>
          <CalendarOutlined className={styles.calendarBackgroundIcon} />

          <div className={styles.calendar}>
            <div className={styles.calendarHeader}>
              <div>
                <span>MESEČNI PREGLED</span>

                <h2>{currentMonth.format("MMMM YYYY")}</h2>
              </div>

              <div className={styles.calendarNavigation}>
                <Button icon={<LeftOutlined />} onClick={previousMonth} />

                <Button onClick={goToday}>Danas</Button>

                <Button icon={<RightOutlined />} onClick={nextMonth} />
              </div>
            </div>

            <div className={styles.customCalendar}>
              {["Pon", "Uto", "Sre", "Čet", "Pet", "Sub", "Ned"].map((day) => (
                <div key={day} className={styles.weekDay}>
                  {day}
                </div>
              ))}

              {calendarCells}
            </div>
          </div>
        </div>
      </Card>

      {/* SELECTED DAY */}

      <div className={styles.daySection}>
        <div className={styles.sectionHeader}>
          <div>
            <span>IZABRANI DAN</span>

            <h2>{selectedDate.format("dddd, DD. MMMM YYYY.")}</h2>
          </div>

          <div className={styles.dayCount}>
            {selectedDayAppointments.length}{" "}
            {selectedDayAppointments.length === 1 ? "termin" : "termina"}
          </div>
        </div>

        {selectedDayAppointments.length === 0 ? (
          <Card className={styles.emptyDayCard}>
            <Empty
              image={Empty.PRESENTED_IMAGE_SIMPLE}
              description="Nema zakazanih termina za ovaj dan."
            />
          </Card>
        ) : (
          <div className={styles.dayAppointmentsList}>
            {selectedDayAppointments.map((appointment) => {
              const user = appointment.expand?.user;

              const pet = appointment.expand?.pet;

              const service = appointment.expand?.service;

              return (
                <Card
                  key={appointment.id}
                  className={styles.dayAppointmentCard}
                >
                  <div className={styles.appointmentTime}>
                    <strong>{dayjs(appointment.date).format("HH:mm")}</strong>

                    <span>
                      {service?.duration ? `${service.duration} min` : "Termin"}
                    </span>
                  </div>

                  <div className={styles.appointmentMain}>
                    <div className={styles.appointmentTitle}>
                      <h3>{service?.name || "Usluga"}</h3>

                      {getStatusTag(appointment.status)}
                    </div>

                    <div className={styles.appointmentInfo}>
                      <span>
                        <UserOutlined />

                        {user?.name ||
                          user?.username ||
                          user?.email ||
                          "Nepoznat korisnik"}
                      </span>

                      <span>
                        <HeartOutlined />

                        {pet?.name || "Nepoznat ljubimac"}
                      </span>

                      <span>
                        <MedicineBoxOutlined />

                        {service?.price != null
                          ? `${Number(service.price).toLocaleString(
                              "sr-RS",
                            )} RSD`
                          : "—"}
                      </span>
                    </div>
                  </div>

                  <Button
                    icon={<EyeOutlined />}
                    onClick={() => openDetails(appointment)}
                  >
                    Detalji
                  </Button>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* DETAILS MODAL */}

      <Modal
        title="Detalji zakazivanja"
        open={detailsOpen}
        onCancel={() => {
          setDetailsOpen(false);
          setSelectedAppointment(null);
        }}
        footer={[
          selectedAppointment?.status === "pending" && (
            <Button
              key="reject"
              danger
              icon={<CloseCircleOutlined />}
              loading={updatingStatus}
              onClick={() => updateAppointmentStatus("rejected")}
            >
              Odbij termin
            </Button>
          ),

          selectedAppointment?.status === "pending" && (
            <Button
              key="confirm"
              type="primary"
              icon={<CheckCircleOutlined />}
              loading={updatingStatus}
              onClick={() => updateAppointmentStatus("confirmed")}
            >
              Potvrdi termin
            </Button>
          ),

          selectedAppointment?.status === "confirmed" && (
            <Button
              key="complete"
              type="primary"
              icon={<CheckCircleOutlined />}
              loading={updatingStatus}
              onClick={() => updateAppointmentStatus("completed")}
            >
              Završi termin
            </Button>
          ),

          <Button
            key="close"
            onClick={() => {
              setDetailsOpen(false);
              setSelectedAppointment(null);
            }}
          >
            Zatvori
          </Button>,
        ].filter(Boolean)}
      >
        {selectedAppointment && (
          <div className={styles.details}>
            <div className={styles.detailsStatus}>
              {getStatusTag(selectedAppointment.status)}
            </div>

            <div className={styles.detailRow}>
              <span>Datum i vreme</span>

              <strong>
                {dayjs(selectedAppointment.date).format(
                  "DD.MM.YYYY. [u] HH:mm",
                )}
              </strong>
            </div>

            <div className={styles.detailRow}>
              <span>Usluga</span>

              <strong>
                {selectedAppointment.expand?.service?.name || "—"}
              </strong>
            </div>

            <div className={styles.detailRow}>
              <span>Cena</span>

              <strong>
                {selectedAppointment.expand?.service?.price != null
                  ? `${Number(
                      selectedAppointment.expand.service.price,
                    ).toLocaleString("sr-RS")} RSD`
                  : "—"}
              </strong>
            </div>

            <div className={styles.detailRow}>
              <span>Trajanje</span>

              <strong>
                {selectedAppointment.expand?.service?.duration
                  ? `${selectedAppointment.expand.service.duration} min`
                  : "—"}
              </strong>
            </div>

            <div className={styles.detailRow}>
              <span>Klijent</span>

              <strong>
                {selectedAppointment.expand?.user?.name ||
                  selectedAppointment.expand?.user?.username ||
                  selectedAppointment.expand?.user?.email ||
                  "—"}
              </strong>
            </div>

            <div className={styles.detailRow}>
              <span>Ljubimac</span>

              <strong>{selectedAppointment.expand?.pet?.name || "—"}</strong>
            </div>

            {selectedAppointment.note && (
              <div className={styles.detailNote}>
                <span>Napomena</span>

                <p>{selectedAppointment.note}</p>
              </div>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}
