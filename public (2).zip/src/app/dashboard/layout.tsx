"use client";

import { useState } from "react";

import Sidebar from "@/components/layout/Sidebar";
import AuthGuard from "@/components/AuthGuard";

import styles from "./DashboardLayout.module.css";

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <AuthGuard>
      <div className={styles.layout}>
        <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} />

        <main className={styles.main}>
          <div className={styles.content}>{children}</div>
        </main>
      </div>
    </AuthGuard>
  );
}
