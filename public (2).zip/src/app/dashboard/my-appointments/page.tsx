"use client";

import React, { useEffect, useState } from "react";
import {
  Table,
  Tag,
  Button,
  Card,
  Popconfirm,
  message,
  Typography,
  Empty,
} from "antd";
import {
  CalendarOutlined,
  EnvironmentOutlined,
  DeleteOutlined,
  CheckCircleOutlined,
  ClockCircleOutlined,
  CloseCircleOutlined,
} from "@ant-design/icons";
import dayjs from "dayjs";

import pb from "@/app/lib/pocketbase";
import styles from "./my-appointments.module.css";

const { Title, Text } = Typography;

interface Appointment {
  id: string;
  user: string;
  location: string;
  pet: string;
  service: string;
  date: string;
  status: "pending" | "confirmed" | "rejected" | "completed";
  note?: string;

  expand?: {
    location?: any;
    pet?: any;
    service?: any;
  };
}

export default function MyAppointmentsPage() {
  const [messageApi, contextHolder] = message.useMessage();

  const [loading, setLoading] = useState(true);
  const [appointments, setAppointments] = useState<Appointment[]>([]);

  /* =========================================================
FETCH APPOINTMENTS
========================================================= */

  const fetchAppointments = async () => {
    try {
      setLoading(true);

      const userId = pb.authStore.model?.id;

      if (!userId) {
        setAppointments([]);
        return;
      }

      const data = await pb
        .collection("appointments")
        .getFullList<Appointment>({
          filter: `user = "${userId}"`,
          expand: "location,pet,service",
          sort: "-date",
          requestKey: null,
        });

      setAppointments(data);
    } catch (err) {
      console.error("Greška pri preuzimanju termina:", err);

      messageApi.error("Greška pri preuzimanju vaših termina.");
    } finally {
      setLoading(false);
    }
  };

  /* =========================================================
INITIAL LOAD
========================================================= */

  useEffect(() => {
    fetchAppointments();
  }, []);

  /* =========================================================
CANCEL APPOINTMENT
========================================================= */

  const handleCancelAppointment = async (id: string) => {
    try {
      await pb.collection("appointments").delete(id);

      messageApi.success("Termin je uspešno otkazan.");

      await fetchAppointments();
    } catch (err) {
      console.error("Greška pri otkazivanju termina:", err);

      messageApi.error("Greška pri otkazivanju termina.");
    }
  };

  /* =========================================================
STATUS
========================================================= */

  const renderStatus = (status: Appointment["status"]) => {
    switch (status) {
      case "pending":
        return (
          <Tag
            color="warning"
            icon={<ClockCircleOutlined />}
            className={styles.statusTag}
          >
            ČEKA POTVRDU{" "}
          </Tag>
        );

      case "confirmed":
        return (
          <Tag
            color="success"
            icon={<CheckCircleOutlined />}
            className={styles.statusTag}
          >
            POTVRĐENO
          </Tag>
        );

      case "rejected":
        return (
          <Tag
            color="error"
            icon={<CloseCircleOutlined />}
            className={styles.statusTag}
          >
            ODBIJENO
          </Tag>
        );

      case "completed":
        return (
          <Tag
            color="blue"
            icon={<CheckCircleOutlined />}
            className={styles.statusTag}
          >
            ZAVRŠENO
          </Tag>
        );

      default:
        return <Tag className={styles.statusTag}>NEPOZNATO</Tag>;
    }
  };

  /* =========================================================
TABLE COLUMNS
========================================================= */

  const columns = [
    {
      title: "Objekat",
      dataIndex: ["expand", "location", "name"],
      key: "location",

      render: (text: string, record: Appointment) => (
        <div className={styles.locationWrapper}>
          <div className={styles.locationName}>
            {text || "Nepoznat objekat"}
          </div>

          <div className={styles.locationAddress}>
            <EnvironmentOutlined />

            <span>
              {record.expand?.location?.address || "Nepoznata adresa"}
            </span>
          </div>
        </div>
      ),
    },

    {
      title: "Ljubimac",
      dataIndex: ["expand", "pet", "name"],
      key: "pet",

      render: (text: string) => (
        <span className={styles.petName}>🐾 {text || "Nepoznat ljubimac"}</span>
      ),
    },

    {
      title: "Usluga",
      dataIndex: ["expand", "service", "name"],
      key: "service",

      render: (text: string, record: Appointment) => (
        <div className={styles.serviceWrapper}>
          <div className={styles.serviceName}>{text || "Nepoznata usluga"}</div>

          {record.expand?.service?.price !== undefined &&
            record.expand?.service?.price !== null && (
              <div className={styles.servicePrice}>
                {Number(record.expand.service.price).toLocaleString("sr-RS")}{" "}
                RSD
              </div>
            )}
        </div>
      ),
    },

    {
      title: "Datum i vreme",
      dataIndex: "date",
      key: "date",

      render: (date: string) => {
        const appointmentDate = dayjs(date);

        return (
          <div className={styles.dateWrapper}>
            <div className={styles.dateBadge}>
              <CalendarOutlined />

              <span>{appointmentDate.format("DD.MM.YYYY.")}</span>
            </div>

            <div className={styles.timeText}>
              {appointmentDate.format("HH:mm")}
            </div>
          </div>
        );
      },
    },

    {
      title: "Status",
      dataIndex: "status",
      key: "status",

      render: (status: Appointment["status"]) => renderStatus(status),
    },

    {
      title: "Akcija",
      key: "action",

      render: (_: any, record: Appointment) => {
        const appointmentDate = dayjs(record.date);

        const isPast = appointmentDate.isBefore(dayjs());

        /* -----------------------------------------------------
       ZAVRŠEN TERMIN
    ----------------------------------------------------- */

        if (record.status === "completed") {
          return <span className={styles.pastAppointment}>Završeno</span>;
        }

        /* -----------------------------------------------------
       ODBIJEN TERMIN
    ----------------------------------------------------- */

        if (record.status === "rejected") {
          return <span className={styles.pastAppointment}>Nije potvrđeno</span>;
        }

        /* -----------------------------------------------------
       PROŠAO TERMIN
    ----------------------------------------------------- */

        if (isPast) {
          return <span className={styles.pastAppointment}>Završeno</span>;
        }

        /* -----------------------------------------------------
       AKTIVAN TERMIN
    ----------------------------------------------------- */

        return (
          <Popconfirm
            title="Otkazivanje termina"
            description="Da li ste sigurni da želite da otkažete ovaj termin?"
            onConfirm={() => handleCancelAppointment(record.id)}
            okText="Da, otkaži"
            cancelText="Ne"
            placement="topRight"
          >
            <Button
              danger
              type="text"
              icon={<DeleteOutlined />}
              size="small"
              className={styles.cancelBtn}
            >
              Otkaži
            </Button>
          </Popconfirm>
        );
      },
    },
  ];

  /* =========================================================
RENDER
========================================================= */

  return (
    <div className={styles.container}>
      {contextHolder}

      {/* =====================================================
      HEADER
  ===================================================== */}

      <div className={styles.titleWrapper}>
        <div>
          <Title level={2} className={styles.pageTitle}>
            Moji Termini
          </Title>

          <Text type="secondary">
            Pregled svih zakazanih poseta i njihovih statusa
          </Text>
        </div>

        <div className={styles.appointmentCount}>
          {appointments.length}{" "}
          {appointments.length === 1 ? "termin" : "termina"}
        </div>
      </div>

      {/* =====================================================
      APPOINTMENTS TABLE
  ===================================================== */}

      <Card className={styles.headerCard} style={{ marginTop: 24 }}>
        {appointments.length === 0 && !loading ? (
          <Empty
            image={Empty.PRESENTED_IMAGE_SIMPLE}
            description={
              <div className={styles.emptyContent}>
                <strong>Nemate zakazanih termina</strong>

                <span>
                  Kada zakažete pregled ili neku drugu uslugu, vaši termini će
                  se pojaviti ovde.
                </span>
              </div>
            }
          />
        ) : (
          <Table
            columns={columns}
            dataSource={appointments}
            rowKey="id"
            loading={loading}
            pagination={{
              pageSize: 8,
              showSizeChanger: false,
            }}
            scroll={{ x: 900 }}
          />
        )}
      </Card>
    </div>
  );
}
